<?php
//buttons for sale info page

$_['button_despatch']                           = 'Delivery Note';

?>
