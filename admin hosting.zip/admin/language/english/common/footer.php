<?php
// Text
$_['text_footer'] = 'Bunga Indo &copy; 2009-' . date('Y') . ' All Rights Reserved.';
?>