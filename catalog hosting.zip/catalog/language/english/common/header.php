<?php
// Text

$_['text_home']           = 'Home';
$_['text_wishlist']       = 'Wish List (%s)';
$_['text_shopping_cart']  = 'Shopping Cart';
$_['text_search']         = 'Search';
$_['text_welcome']        = '<li><a href="%s">Register<span class="cart_divider"></span>Sign in</a></li><!--<li><a href="%s">Sign in</a></li>-->';
//$_['text_logged']         = 'You are logged in as <a href="%s">%s</a> <b>(</b> <a href="%s">Logout</a> <b>)</b>';
$_['text_logged']         = '<li><a href="%s">My Account</a><span class="cart_divider"></span><a href="%s">Logout</a></li> ';
$_['text_account']        = 'My Account';
$_['text_checkout']       = 'Checkout';
?>