<?php
// Heading
$_['heading_title'] = 'Thank-you!';

// Text
$_['text_customer'] = '<p>Your Transaction has been successfull!</p>';
$_['text_guest']    = '<p>Your order has been successfully processed!</p><p>Please direct any questions you have to the <a href="%s">store owner</a>.</p><p>Thanks for shopping with us online!</p>';
$_['text_end']   = 'Please confirm your payment within 3x24 hours or your order will be cancelled from our system.After payment completed simply click on "CONFIRM PAYMENT" link on my account and follow the steps.You have to confirm your payment on webstore to prevent our system from deleting your order. ';
$_['text_basket']   = 'Shopping Cart';
$_['text_checkout'] = 'Checkout';
$_['text_success']  = 'Success';
?>