<?php
$_['text_credit']   = 'Credit Balance';
$_['text_order_id'] = 'Order ID: #%s';
?>