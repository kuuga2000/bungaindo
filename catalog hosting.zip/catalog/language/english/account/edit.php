<?php
// Heading 
$_['heading_title']     = 'My Account Information';
$_['credit_heading']     = 'Credit Balance';


// Text
$_['text_account']      = 'Account';
$_['text_edit']         = 'Edit Information';
$_['text_your_details'] = 'Your Personal Information';
$_['text_success']      = 'Success: Your account has been successfully updated.';

$_['text_credit_balance'] = '<div style="margin:0 0 5px 0;">You have credit balance</div> <span class="big_ttl">IDR %s</span>';

// Entry
$_['entry_firstname']  = 'First Name';
$_['entry_lastname']   = 'Last Name';
$_['entry_email']      = 'E-Mail';
$_['entry_telephone']  = 'Telephone';
$_['entry_fax']        = 'Fax';
$_['entry_password']       = 'Password';
$_['entry_confirm']        = 'Password Confirm';

// Error
$_['error_exists']     = 'Warning: E-Mail address is already registered!';
$_['error_firstname']    = 'You must fill in this form';
$_['error_lastname']     = 'You must fill in this form';
$_['error_email']        = 'You must fill in this form';
$_['error_telephone']  = 'Telephone must be between 3 and 32 characters!';
$_['error_password']       = 'You must fill in this form';
$_['error_confirm']        = 'Password and Confirm Password did not match';
?>