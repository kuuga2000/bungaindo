<?php
// Heading 
$_['heading_title']      = 'My Account';

// Text
$_['text_account']       = 'Account';

?>