<?php
// Text
$_['text_account']       = 'Account';
$_['text_my_account']    = 'My Account';

$_['text_my_orders']     = 'My Orders';

$_['text_view']          = 'Profile';
$_['text_edit']          = 'Edit your account information';
$_['text_password']      = 'Change your password';
$_['text_address']       = 'Address book';

$_['text_order']         = 'Track order';

$_['text_logout']      	 = 'Sign out';
?>