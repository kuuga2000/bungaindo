<?php
// Heading 
$_['heading_title']   = 'Forgot Your Password?';

// Text
$_['text_account']    = 'Account';
$_['text_forgotten']  = 'Forgotten Password';
$_['text_your_email'] = 'Your E-Mail Address';
$_['text_email']      = 'Enter your e-mail address below. We will send you a link to reset your password.';
$_['text_success']    = 'SUCCESS <BR/> Please check your e-mail.See you again!<br/>Thank-you.';

// Entry
$_['entry_email']     = 'E-Mail Address:';

// Error
$_['error_email']     = 'ERROR <br/> Your E-Mail Address incorrect.<br/> Please check and try again!';
?>